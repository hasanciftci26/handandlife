sap.ui.define([
    "renova/hl/ui/artisan/controller/BaseController",
    "sap/ui/core/mvc/Controller"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (BaseController, Controller) {
        "use strict";

        return BaseController.extend("renova.hl.ui.artisan.controller.App", {
            onInit: function () {

            }
        });
    });